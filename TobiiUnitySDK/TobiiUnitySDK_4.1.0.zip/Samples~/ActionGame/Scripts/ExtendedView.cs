namespace Tobii.Gaming.Examples.ActionGame
{
    public class ExtendedView : ExtendedViewBase
    {
        //// <summary>
        //// Bind extended view sensitivity settings here
        //// </summary>
        //protected override void UpdateSettings()
        //{
        //    var gazeSensitivitySlider = 0.5f; //min 0 - 1 max
        //    var headSensitivitySlider = 0.5f; //min 0 - 1 max
        //    var gazeAngleSlider = 0.5f; //min 0 - 1 max

        //    GazeViewResponsiveness = 0.25f + gazeSensitivitySlider * 0.5f;
        //    HeadViewSensitivityScale = HeadViewSensitivityScaleHeadOnly = 0.5f + headSensitivitySlider * 0.5f;
        //    GazeViewExtensionAngle = GazeViewExtensionAngleGazeOnly = (10 + gazeAngleSlider * 20);
        //}
    }
}
