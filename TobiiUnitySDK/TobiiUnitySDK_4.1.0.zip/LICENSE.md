https://developer.tobii.com/license-agreement/
