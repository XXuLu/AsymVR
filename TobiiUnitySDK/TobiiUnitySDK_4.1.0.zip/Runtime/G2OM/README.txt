Gaze-2-Object-Mapping (G2OM) library for Unity
Copyright � 2018 � Property of Tobii AB (publ) - All Rights Reserved

ALL OF THE CODE IS SUBJECT TO CHANGE

Summary of G2OM:
G2OM is a sophisticated solution to address the problem of mapping gaze data to objects in an XR context.


If you have any feedback, suggestions or comments please send that to rtm@tobii.com or swik@tobii.com.