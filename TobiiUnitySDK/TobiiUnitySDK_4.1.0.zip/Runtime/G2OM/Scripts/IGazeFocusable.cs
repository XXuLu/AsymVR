﻿// Copyright © 2018 – Property of Tobii AB (publ) - All Rights Reserved

namespace Tobii.G2OM
{
    public interface IGazeFocusable
    {
        void GazeFocusChanged(bool hasFocus);
    }
}